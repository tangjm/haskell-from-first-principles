module Addition where

import Test.Hspec
import Test.QuickCheck

sayHello :: IO ()
sayHello = putStrLn "hello!"

dividedBy :: Integral a => a -> a -> (a, a)
dividedBy num denom = go num denom 0
  where go n d count
          | n < d = (count, n)
          | otherwise = go (n - d) d (count + 1)

mult :: (Eq a , Num a) => a -> a -> a 
mult x y 
  | y == 0    = y
  | otherwise = (+) (mult x (y - 1)) x

main :: IO ()
main = hspec $ do
  describe "Addition" $ do
    it "15 divided by 3 is 5" $ do
      dividedBy 15 3 `shouldBe` (5, 0)
    
    it "22 divided by 5 is 4 remainder 2" $ do
      dividedBy 22 5 `shouldBe` (4, 2)

  describe "Multiplication" $ do
    it "0 times 2 is 0" $ do
      mult 0 2 `shouldBe` 0
    
    it "2 times 3 is 6" $ do
      mult 2 3 `shouldBe` 6
    
    it "3 times 0 is 0" $ do
      mult 3 0  `shouldBe` 0
